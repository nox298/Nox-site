async function fetchGPTResponse(message) {
  const output = document.getElementById("output");
  output.innerHTML += "NOX düşünüyor...\n";

  try {
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": "Bearer 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"
      },
      body: JSON.stringify({
        model: "gpt-3.5-turbo",
        messages: [{ role: "user", content: message }]
      })
    });

    const data = await response.json();
    const reply = data.choices?.[0]?.message?.content || "NOX cevap veremedi.";
    output.innerHTML += "💬 " + reply + "\n";
  } catch (err) {
    output.innerHTML += "❌ Hata: " + err.message + "\n";
  }
}